<?php
require_once 'Database.php';
require_once 'Variation.php';
class Product {
    public $id, $name, $price, $stock, $variation;

    public function __construct($id = null, $name, $price, $stock, $variation) {
        $this->id = $id;
        $this->name = $name;
        $this->price = $price;
        $this->stock = $stock;
        $this->variation = $variation;
    }

    public function loadById($id) {
        $stmt = Database::getConnection()->prepare("SELECT * FROM products WHERE id = ?");
        $stmt->execute([$id]);
        $date = $stmt->fetch();
        if ($date) {
            $this->id = $date['id'];
            $this->name = $date['name'];
            $this->price = $date['price'];
            $this->stock = $date['stock'];
        }
    }

    public function save($product) {
        $stmt = Database::getConnection()->prepare("INSERT INTO products (name, price, stock, variation) VALUES (?, ?, ?, ?)");
        return $stmt->execute([$product->name, $product->price, $product->stock, $product->variation]);
    }

    public function updateProduct($product) {
        $stmt = Database::getConnection()->prepare("UPDATE products SET name = ?, price = ?, stock = ?, variation = ? WHERE id = ?");
        return $stmt->execute([$product->name, $product->price, $product->stock, $product->variation, $product->id]);
    }

    public static function listAll() {
        $stmt = Database::getConnection()->query("SELECT * FROM products WHERE deleted_at IS NULL");
        return $stmt->fetchAll();
    }

    public static function deleteProduct($id) {
        $dateNow = date('Y-m-d H:i:s');
        $stmt = Database::getConnection()->query("UPDATE products SET deleted_at = '$dateNow' WHERE id = '$id'");
        $stmt->execute();
    }

    public static function searchProductById($id) {
        $stmt = Database::getConnection()->prepare("SELECT * FROM products WHERE id = ?");
        $stmt->execute([$id]);
        $date = $stmt->fetch();
        return $date;
    }

    public function baixarEstoque($qtd) {
        $stmt = Database::getConnection()->prepare("UPDATE products SET stock = stock - ? WHERE id = ?");
        $stmt->execute([$qtd, $this->id]);
    }

    
}
