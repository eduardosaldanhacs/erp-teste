<?php
require_once 'Database.php';
class Variation
{
    public $id;
    public $name;
    public $active;

    public function registerVariation($name, $active)
    {
        try {
            $stmt = Database::getConnection()->prepare("INSERT INTO variation (name, active) VALUES (?, ?)");
            return $stmt->execute([$name, $active]);
        } catch (PDOException $e) {
            error_log("Erro ao cadastrar variação: " . $e->getMessage());
            return false;
        }
    }

    public static function searchVariationById($id)
    {
        $stmt = Database::getConnection()->prepare("SELECT * FROM variation WHERE id = ? AND active = 1");
        $stmt->execute([$id]);
        $data = $stmt->fetch();
        return $data['name'] ?? null; 
    }

    public static function searchAllVariations()
    {
        $stmt = Database::getConnection()->prepare("SELECT * FROM variation WHERE active = 1");
        $stmt->execute();
        return $stmt->fetchAll();
    }
}
