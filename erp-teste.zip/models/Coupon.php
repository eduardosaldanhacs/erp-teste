<?php
require_once 'Database.php';

class Coupon
{
    public $id;
    public $code;
    public $discount;
    public $validate;

    public function __construct($code, $discount, $validate, $id = null)
    {
        $this->code = $code;
        $this->discount = $discount;
        $this->validate = $validate;
        $this->id = $id;
    }

    public static function searchCouponById($id)
    {
        $stmt = Database::getConnection()->prepare("SELECT * FROM coupons WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public static function listAll()
    {
        $stmt = Database::getConnection()->query("SELECT * FROM coupons WHERE deleted_at IS NULL");
        return $stmt->fetchAll();
    }

    public function salvar($coupon)
    {
        $stmt = Database::getConnection()->prepare("INSERT INTO coupons (code, discount, validate) VALUES (?, ?, ?)");
        $stmt->bindParam(1, $coupon->code);
        $stmt->bindParam(2, $coupon->discount);
        $stmt->bindParam(3, $coupon->validate);
        if ($stmt->execute()) {
            return true;
        } else {
            return false;
        }
    }

    public function updateCoupon($coupon)
    {
        $stmt = Database::getConnection()->prepare("UPDATE coupons SET code = ?, discount = ?, validate = ? WHERE id = ?");
        $stmt->bindParam(1, $coupon->code);
        $stmt->bindParam(2, $coupon->discount);
        $stmt->bindParam(3, $coupon->validate);
        $stmt->bindParam(4, $coupon->id);
        if ($stmt->execute()) {
            return true;
        } else {
            return false;
        }
    }

    public static function deleteCoupon($id)
    {
        $dateNow = date('Y-m-d H:i:s');
        $stmt = Database::getConnection()->query("UPDATE coupons SET deleted_at = '$dateNow' WHERE id = '$id'");
        if ($stmt->execute()) {
            return true;
        } else {
            return false;
        }
    }
}
