<?php
include_once('models/Product.php');
include_once('models/Variation.php');

if (isset($_POST['id']) && !empty($_POST['id'])) {
  $product = Product::searchProductById($_POST['id']);
  $action = 'update';
  $button = 'Atualizar';
} else {
  $action = 'create';
  $button = 'Cadastrar';
}
$variations = Variation::searchAllVariations();
?>

<div class="row align-items-center justify-content-center">
  <div class="col-8">
    <form method="POST" class="p-4 bg-light rounded" action="<?= BASE_URL ?>controllers/product_controller.php">
      <h2 class="text-center">Novo Produto</h2>
      <div class="col-12">
        <label for="Nome" class="form-label">Nome: </label>
        <input class="form-control mb-2" name="name" value="<?= $product['name'] ?? '' ?>">
      </div>
      <div class="col-12">
        <label for="Preço" class="form-label">Preço: </label>
        <input class="form-control mb-2" name="price" value="<?= $product['price'] ?? '' ?>" placeholder="Ex: 50, 100">
      </div>
      <div class="col-12">
        <label for="Variações" class="form-label">Variações: </label>
        <select name="variations" id="" class="form-select mb-2">
          <option value="">---</optio>
            <?php foreach ($variations as $variation) {
              if (isset($product['variation'])) { ?>
          <option value="<?= $variation['name'] ?>" <?= $variation['name'] == $product['variation'] ? 'selected' : '' ?>><?= $variation['name'] ?></option>
        <?php } ?>
        <option value="<?= $variation['name'] ?>"><?= $variation['name'] ?></option>
      <?php } ?>
        </select>
      </div>
      <div class="col-12">
        <label for="Estoque" class="form-label">Estoque: </label>
        <input class="form-control mb-2" name="stock" value="<?= $product['stock'] ?? '' ?>">
      </div>
      <div class="mt-3">
        <input type="hidden" name="id" value="<?= $product['id'] ?? '' ?>">
        <input type="hidden" name="action" value="<?= $action == 'update' ? 'update' : 'create' ?>">
        <button class="btn btn-outline-success w-100" type="submit"><?= $button ?></button>
      </div>
    </form>
  </div>
</div>