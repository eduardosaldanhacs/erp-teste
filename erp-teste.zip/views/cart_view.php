<div id="carrinho" class="col-4 bg-dark text-white rounded shadow position-absolute z-3 p-3"
    style="right: 20px; max-height: 450px; overflow-y: auto; <?= $exibirCarrinho ? '' : 'display: none;' ?>">
    <?php $total = 0.0; ?>
    <?php if (!empty($_SESSION['cart'])): ?>
        <form method="post" action="http://localhost/erp-teste/checkout.php">
            <?php foreach ($_SESSION['cart'] as $id => $item): ?>
                <div class="bg-light text-dark rounded p-2 mb-2">
                    <div class="d-flex justify-content-between">
                        <div>
                            <p class="m-0 fw-bold">Produto: <?= $item['name'] ?></p>
                            <p class="m-0">Preço: <span class="text-success">R$ <?= number_format($item['price'], 2, ',', '.') ?></span></p>
                            <p class="m-0">Quantidade: <span class="text-primary"><?= $item['amount'] ?></span></p>
                        </div>
                        <div class="text-end">
                            <a href="controllers/remove_item.php?id=<?= $id ?>" class="text-danger text-end"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                                    <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0z" />
                                    <path d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4zM2.5 3h11V2h-11z" />
                                </svg>
                            </a>
                            <p class="m-0 mt-2">
                                Subtotal: <span id="subtotal-atual" class="text-success">
                                    R$ <?= number_format($item['price'] * $item['amount'], 2, ',', '.') ?>
                                </span>
                            </p>
                        </div>
                    </div>
                </div>
                <?php $total += $item['price'] * $item['amount']; ?>
            <?php endforeach;
            $_SESSION['total_cart'] = $total;
            ?>
            <div id="frete-content">
                <div class="row">
                    <div class="col-6">
                        <input name="cep" type="text" class="form-control" required id="cep" value="" size="10" maxlength="9" placeholder="CEP" />
                    </div>
                    <div class="col-6">
                        <button onclick="pesquisacep()" type="button" class="btn btn-warning w-100">Pesquisar</button>
                    </div>
                    <div class="col-8 mt-2">
                        <input name="rua" type="text" class="form-control fs-6" id="rua" size="60" placeholder="Endereço" />
                    </div>
                    <div class="col-4 mt-2">
                        <input name="bairro" type="text" class="form-control fs-6" id="bairro" size="40" placeholder="Bairro" />
                    </div>
                    <div class="col-2 mt-2">
                        <input name="uf" type="text" class="form-control fs-6" id="uf" size="2" placeholder="UF" />
                    </div>
                    <div class="col-10 mt-2">
                        <input name="cidade" type="text" class="form-control fs-6" id="cidade" size="40" placeholder="Cidade" />
                    </div>
                </div>
            </div>
            <hr>
            <!-- Frete e total -->
            <?php
            if ($total > 200) $frete = 0;
            elseif ($total > 52) $frete = 15;
            else $frete = 20;
            ?>
            <div class="row mt-3">
                <div class="col-6">
                    <p>Subtotal: <span id="subtotal" class="text-success">R$ <?= number_format($total, 2, ',', '.') ?></span></p>
                    <p>Frete: <span id="frete" class="text-warning">R$ <?= number_format($frete, 2, ',', '.') ?></span></p>
                    <p class="fw-bold">Total: <span id="total" class="text-success fs-5">R$ <?= number_format($total + $frete, 2, ',', '.') ?></span></p>
                </div>
                <div class="col-6">
                    <label for="cupom">Cupom</label>
                    <input type="text" name="cupom" id="cupom" class="form-control mt-1" placeholder="Digite e pressione Enter">
                    <div id="mensagem-cupom" class="mt-1 small"></div>
                </div>
            </div>
            <div class="row">
                <div class="col-6 mb-2">
                    <input type="text" name="client_name" class="form-control mt-2" placeholder="Preencha o seu nome" required>
                </div>
                <div class="col-6 mb-2">
                    <input type="email" name="client_email" class="form-control mt-2" placeholder="Preencha o seu email" required>
                </div>
                <div class="text-end">
                    <button class="btn btn-success" type="submit">Finalizar Compra</button>
                    <button class="btn btn-danger" onclick="fecharCarrinho()">Fechar</button>
                </div>
        </form>
    <?php else: ?>
        <p class="text-light">Carrinho vazio.</p>
    <?php endif; ?>
</div>