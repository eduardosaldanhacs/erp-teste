<?php
include_once("models/Product.php");
$products = Product::listAll();
?>


<div class="col-3 text-end">
    <a href="<?= BASE_URL ?>new_product" class="text-light text-decoration-none w-100 btn btn-success mb-2">Novo Produto</a>
</div>
<table class="table table-striped">
    <thead>
        <tr class="text-center">
            <th>#</th>
            <th>Product</th>
            <th>Preço</th>
            <th>Estoque</th>
            <th>Variação</th>
            <th>Ações</th>
        </tr>
    </thead>
    <tbody>
        <?php $i = 1; ?>
        <?php foreach ($products as $product): ?>
            <tr class="align-middle text-center">
                <td><?= $i ?></td>
                <td><?= $product['name'] ?></td>
                <td>R$ <?= number_format($product['price'], 2, ',', '.') ?></td>
                <td><?= $product['stock'] ?></td>
                <td><?= Variation::searchVariationById($product['variation']) ?></td>
                <td>
                    <div class="d-flex justify-content-center align-items-center">
                        <form action="<?= BASE_URL ?>new_product" class="ms-1" method="POST">
                            <input type="hidden" name="id" value="<?= $product['id'] ?>">
                            <button type="submit" class="btn btn-info">Editar</button>
                        </form>

                        <form action="<?= BASE_URL ?>controllers/product_controller.php" class="ms-1" method="POST">
                            <input type="hidden" name="id" value="<?= $product['id'] ?>">
                            <input type="hidden" name="action" value="delete">
                            <button type="submit" class="btn btn-danger">Excluir</button>
                        </form>

                        <form action="<?= BASE_URL ?>controllers/add_to_cart.php" class="ms-1" method="POST">
                            <input type="hidden" name="id" value="<?= $product['id'] ?>">
                            <input type="hidden" name="name" value="<?= $product['name'] ?>">
                            <input type="hidden" name="price" value="<?= $product['price'] ?>">
                            <button class="btn btn-success">Comprar</button>
                        </form>
                    </div>
                </td>
            </tr>
        <?php $i++;
        endforeach;  ?>
        <?php if (empty($products)) { ?>
            <tr>
                <td colspan='8' class='text-center'>Nenhum pedido encontrado</td>
            </tr>
        <?php } ?>
    </tbody>
</table>

<div id="mensagem" class="mt-3"></div>
<div></div>


<!-- jQuery ou JavaScript puro para AJAX -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(".comprar-btn").click(function() {
        const id = $(this).data("id");
        const name = $(this).data("name");
        const price = $(this).data("price");

        $.post("<?= BASE_URL ?>controllers/add_to_cart.php", {
            id: id,
            name: name,
            price: price
        }, function(resposta) {
            $("#mensagem").html('<div class="alert alert-success">' + resposta + '</div>');
        });
    });
</script>