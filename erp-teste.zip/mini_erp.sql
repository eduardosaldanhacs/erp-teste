/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 80200 (8.2.0)
 Source Host           : localhost:3306
 Source Schema         : mini_erp

 Target Server Type    : MySQL
 Target Server Version : 80200 (8.2.0)
 File Encoding         : 65001

 Date: 27/05/2025 16:25:06
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for coupons
-- ----------------------------
DROP TABLE IF EXISTS `coupons`;
CREATE TABLE `coupons`  (
  `discount` decimal(10, 2) NULL DEFAULT NULL,
  `validate` date NULL DEFAULT NULL,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `created_at` datetime NULL DEFAULT NULL,
  `deleted_at` datetime NULL DEFAULT NULL,
  `code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  `min_value` decimal(10, 2) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of coupons
-- ----------------------------
INSERT INTO `coupons` VALUES (50.00, '2025-05-29', NULL, NULL, NULL, 'DESCONTA50', 1, NULL);
INSERT INTO `coupons` VALUES (99.00, '2025-08-30', NULL, NULL, NULL, 'VERAO99', 2, NULL);
INSERT INTO `coupons` VALUES (100.00, '2035-05-30', NULL, NULL, NULL, 'USUARIONOVO100', 3, NULL);

-- ----------------------------
-- Table structure for order_items
-- ----------------------------
DROP TABLE IF EXISTS `order_items`;
CREATE TABLE `order_items`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `product_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `quantity` int NULL DEFAULT NULL,
  `price` decimal(10, 2) NULL DEFAULT NULL,
  `deleted_at` datetime NULL DEFAULT NULL,
  `created_at` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `order_id`(`order_id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 29 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of order_items
-- ----------------------------
INSERT INTO `order_items` VALUES (1, 1, 'Tênis Olympikus Veloz', 1, 199.90, '2025-05-27 10:47:48', NULL);
INSERT INTO `order_items` VALUES (2, 1, 'Camiseta Adidas Essentials', 1, 84.90, '2025-05-27 10:47:48', NULL);
INSERT INTO `order_items` VALUES (3, 2, 'Tênis Olympikus Veloz', 1, 199.90, '2025-05-27 10:47:44', NULL);
INSERT INTO `order_items` VALUES (4, 2, 'Camiseta Adidas Essentials', 1, 84.90, '2025-05-27 10:47:44', NULL);
INSERT INTO `order_items` VALUES (5, 3, 'Tênis Olympikus Veloz', 1, 199.90, '2025-05-27 10:47:43', NULL);
INSERT INTO `order_items` VALUES (6, 3, 'Camiseta Adidas Essentials', 1, 84.90, '2025-05-27 10:47:43', NULL);
INSERT INTO `order_items` VALUES (7, 4, 'Tênis Olympikus Veloz', 1, 199.90, '2025-05-27 10:47:42', NULL);
INSERT INTO `order_items` VALUES (8, 4, 'Camiseta Adidas Essentials', 1, 84.90, '2025-05-27 10:47:42', NULL);
INSERT INTO `order_items` VALUES (9, 5, 'Tênis Olympikus Veloz', 1, 199.90, '2025-05-27 10:47:41', NULL);
INSERT INTO `order_items` VALUES (10, 5, 'Camiseta Adidas Essentials', 1, 84.90, '2025-05-27 10:47:41', NULL);
INSERT INTO `order_items` VALUES (11, 6, 'Tênis Olympikus Veloz', 1, 199.90, '2025-05-27 10:47:40', NULL);
INSERT INTO `order_items` VALUES (12, 6, 'Camiseta Adidas Essentials', 1, 84.90, '2025-05-27 10:47:40', NULL);
INSERT INTO `order_items` VALUES (13, 7, 'Tênis Olympikus Veloz', 1, 199.90, '2025-05-27 10:47:39', NULL);
INSERT INTO `order_items` VALUES (14, 7, 'Camiseta Adidas Essentials', 1, 84.90, '2025-05-27 10:47:39', NULL);
INSERT INTO `order_items` VALUES (15, 8, 'Tênis Olympikus Veloz', 1, 199.90, NULL, NULL);
INSERT INTO `order_items` VALUES (16, 8, 'Camiseta Adidas Essentials', 1, 84.90, NULL, NULL);
INSERT INTO `order_items` VALUES (17, 9, 'Tênis Olympikus Veloz', 1, 199.90, '2025-05-27 11:17:07', NULL);
INSERT INTO `order_items` VALUES (18, 9, 'Camiseta Adidas Essentials', 1, 84.90, '2025-05-27 11:17:07', NULL);
INSERT INTO `order_items` VALUES (19, 9, 'Tênis Mizuno Jet 5', 1, 269.90, '2025-05-27 11:17:07', NULL);
INSERT INTO `order_items` VALUES (20, 9, 'Tênis Puma Flyer Runner', 1, 229.90, '2025-05-27 11:17:07', NULL);
INSERT INTO `order_items` VALUES (21, 10, 'Tênis Olympikus Veloz', 1, 199.90, NULL, NULL);
INSERT INTO `order_items` VALUES (22, 10, 'Camiseta Adidas Essentials', 1, 84.90, NULL, NULL);
INSERT INTO `order_items` VALUES (23, 10, 'Tênis Mizuno Jet 5', 1, 269.90, NULL, NULL);
INSERT INTO `order_items` VALUES (24, 10, 'Tênis Puma Flyer Runner', 1, 229.90, NULL, NULL);
INSERT INTO `order_items` VALUES (25, 11, 'Tênis Olympikus Veloz', 1, 199.90, NULL, NULL);
INSERT INTO `order_items` VALUES (26, 11, 'Camiseta Adidas Essentials', 1, 84.90, NULL, NULL);
INSERT INTO `order_items` VALUES (27, 11, 'Tênis Mizuno Jet 5', 1, 269.90, NULL, NULL);
INSERT INTO `order_items` VALUES (28, 11, 'Tênis Puma Flyer Runner', 1, 229.90, NULL, NULL);

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `total` decimal(10, 2) NOT NULL,
  `coupon_id` int NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `client_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `deleted_at` datetime NULL DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `cupom_id`(`coupon_id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of orders
-- ----------------------------
INSERT INTO `orders` VALUES (8, 'Eduardo', 284.80, NULL, '2025-05-27 10:48:13', 'eduardosaldanhacs@gmail.com', 'Rua Engenheiro Rodolfo Ahrons, Partenon - Porto Alegre/RS - CEP: 91530320', NULL, 'Enviado');
INSERT INTO `orders` VALUES (9, 'Joao', 784.60, NULL, '2025-05-27 10:53:41', 'joao@gmail.com', ',  - / - CEP: ', '2025-05-27 11:17:07', 'Pendente');
INSERT INTO `orders` VALUES (10, 'Joao', 784.60, NULL, '2025-05-27 11:11:48', 'joao@gmail.com', 'Rua Engenheiro Rodolfo Ahrons, Partenon - Porto Alegre/RS - CEP: 91530320', NULL, 'Pendente');
INSERT INTO `orders` VALUES (11, 'Joao', 734.60, NULL, '2025-05-27 11:15:28', 'joao@gmail.com', 'Rua Engenheiro Rodolfo Ahrons, Partenon - Porto Alegre/RS - CEP: 91530320', NULL, 'Pendente');

-- ----------------------------
-- Table structure for products
-- ----------------------------
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `price` decimal(10, 2) NOT NULL,
  `stock` int NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `variation` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `deleted_at` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 20 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of products
-- ----------------------------
INSERT INTO `products` VALUES (1, 'Tênis Nike Revolution 6', 249.90, 10, '2025-05-27 10:31:58', '1', NULL);
INSERT INTO `products` VALUES (2, 'Tênis Adidas Runfalcon 2.0', 279.90, 8, '2025-05-27 10:31:58', '2', NULL);
INSERT INTO `products` VALUES (3, 'Tênis Puma Flyer Runner', 229.90, 15, '2025-05-27 10:31:58', '3', NULL);
INSERT INTO `products` VALUES (4, 'Tênis Asics Gel Excite 9', 299.90, 12, '2025-05-27 10:31:58', '4', NULL);
INSERT INTO `products` VALUES (5, 'Tênis Olympikus Veloz', 199.90, 20, '2025-05-27 10:31:58', '5', NULL);
INSERT INTO `products` VALUES (6, 'Tênis Fila Racer Grid', 219.90, 9, '2025-05-27 10:31:58', '6', NULL);
INSERT INTO `products` VALUES (7, 'Tênis Mizuno Jet 5', 269.90, 7, '2025-05-27 10:31:58', '7', NULL);
INSERT INTO `products` VALUES (8, 'Camiseta Nike Dri-FIT', 89.90, 30, '2025-05-27 10:31:58', '8', NULL);
INSERT INTO `products` VALUES (9, 'Camiseta Adidas Essentials', 84.90, 35, '2025-05-27 10:31:58', '9', NULL);
INSERT INTO `products` VALUES (10, 'Camiseta Puma Essentials', 79.90, 25, '2025-05-27 10:31:58', '10', NULL);
INSERT INTO `products` VALUES (11, 'Camiseta Reebok Workout', 74.90, 22, '2025-05-27 10:31:58', '11', NULL);
INSERT INTO `products` VALUES (12, 'Camiseta Under Armour Sportstyle', 99.90, 15, '2025-05-27 10:31:58', '12', NULL);
INSERT INTO `products` VALUES (13, 'Boné Nike Aba Curva', 119.90, 30, '2025-05-27 10:31:58', '13', NULL);
INSERT INTO `products` VALUES (14, 'Boné Adidas 3-Stripes', 109.90, 28, '2025-05-27 10:31:58', '14', NULL);
INSERT INTO `products` VALUES (15, 'Boné Puma Logo', 99.90, 26, '2025-05-27 10:31:58', '15', NULL);
INSERT INTO `products` VALUES (16, 'Boné Oakley Tinfoil', 129.90, 20, '2025-05-27 10:31:58', '16', NULL);
INSERT INTO `products` VALUES (17, 'Boné New Era Yankees', 139.90, 18, '2025-05-27 10:31:58', '17', NULL);
INSERT INTO `products` VALUES (18, 'Boné Lacoste Sport', 159.90, 24, '2025-05-27 10:31:58', '18', NULL);
INSERT INTO `products` VALUES (19, 'Boné Tommy Hilfiger Classic', 149.90, 21, '2025-05-27 10:31:58', '19', NULL);

-- ----------------------------
-- Table structure for variation
-- ----------------------------
DROP TABLE IF EXISTS `variation`;
CREATE TABLE `variation`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `color` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `size` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `active` int NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 20 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of variation
-- ----------------------------
INSERT INTO `variation` VALUES (1, 'Tamanho 38', NULL, NULL, 1);
INSERT INTO `variation` VALUES (2, 'Tamanho 39', NULL, NULL, 1);
INSERT INTO `variation` VALUES (3, 'Tamanho 40', NULL, NULL, 1);
INSERT INTO `variation` VALUES (4, 'Tamanho 41', NULL, NULL, 1);
INSERT INTO `variation` VALUES (5, 'Tamanho 42', NULL, NULL, 1);
INSERT INTO `variation` VALUES (6, 'Tamanho 43', NULL, NULL, 1);
INSERT INTO `variation` VALUES (7, 'Tamanho 44', NULL, NULL, 1);
INSERT INTO `variation` VALUES (8, 'Tamanho P', NULL, NULL, 1);
INSERT INTO `variation` VALUES (9, 'Tamanho M', NULL, NULL, 1);
INSERT INTO `variation` VALUES (10, 'Tamanho G', NULL, NULL, 1);
INSERT INTO `variation` VALUES (11, 'Tamanho GG', NULL, NULL, 1);
INSERT INTO `variation` VALUES (12, 'Tamanho XG', NULL, NULL, 1);
INSERT INTO `variation` VALUES (13, 'Cor Preta', NULL, NULL, 1);
INSERT INTO `variation` VALUES (14, 'Cor Branca', NULL, NULL, 1);
INSERT INTO `variation` VALUES (15, 'Cor Azul', NULL, NULL, 1);
INSERT INTO `variation` VALUES (16, 'Cor Vermelha', NULL, NULL, 1);
INSERT INTO `variation` VALUES (17, 'Cor Verde', NULL, NULL, 1);
INSERT INTO `variation` VALUES (18, 'Cor Cinza', NULL, NULL, 1);
INSERT INTO `variation` VALUES (19, 'Cor Amarela', NULL, NULL, 1);

SET FOREIGN_KEY_CHECKS = 1;
