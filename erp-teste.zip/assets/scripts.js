
function fecharCarrinho() {
    const carrinho = document.getElementById("carrinho");
    carrinho.style.display = "none";

    fetch('controllers/show_cart_ajax.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: 'exibir=0'
    });
}



function exibirCarrinho() {
    const carrinho = document.getElementById("carrinho");
    let isVisible;

    if (carrinho.style.display == "none") {
        console.log("entrou");
        carrinho.style.display = "block";
        isVisible = true;
    } else {
        console.log("saiu");
        carrinho.style.display = "none";
        isVisible = false;
    }

    //ajax para salvar a opção de exibir ou não o carrinho
    fetch('controllers/show_cart_ajax.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: 'exibir=' + (isVisible ? '1' : '0')
    });
}
//jquery para aplicar cupom e calcular novo valor 

$('#cupom').on('keypress', function (e) {
    if (e.which === 13) {
        e.preventDefault();

        const codigo = $(this).val().trim();
        if (codigo === '') return;

        $.ajax({
            url: 'http://localhost/erp-teste/controllers/check_coupon.php',
            type: 'POST',
            data: {
                codigo
            },
            dataType: 'json',
            success: function (res) {
                if (res.valido) {
                    $('#mensagem-cupom')
                        .text(`Cupom aplicado: R$ ${res.desconto.toFixed(2).replace('.', ',')}`)
                        .css('color', 'green');

                    $('#subtotal').text('R$ ' + res.subtotal.toFixed(2).replace('.', ','));
                    $('#frete').text('R$ ' + res.frete.toFixed(2).replace('.', ','));
                    $('#total').text('R$ ' + res.total.toFixed(2).replace('.', ','));
                } else {
                    $('#mensagem-cupom')
                        .text(res.mensagem)
                        .css('color', 'red');
                }
            },
            error: function () {
                $('#mensagem-cupom')
                    .text('Erro ao validar o cupom.')
                    .css('color', 'red');
            }
        });
    }
});


//scripts do viacep 
function limpa_formulário_cep() {
    //Limpa valores do formulário de cep.
    document.getElementById('rua').value = ("");
    document.getElementById('bairro').value = ("");
    document.getElementById('cidade').value = ("");
    document.getElementById('uf').value = ("");
}

function meu_callback(conteudo) {
    if (!("erro" in conteudo)) {
        //Atualiza os campos com os valores.
        document.getElementById('rua').value = (conteudo.logradouro);
        document.getElementById('bairro').value = (conteudo.bairro);
        document.getElementById('cidade').value = (conteudo.localidade);
        document.getElementById('uf').value = (conteudo.uf);
    } else {
        //CEP não Encontrado.
        limpa_formulário_cep();
        alert("CEP não encontrado.");
    }
}

function pesquisacep(valor) {
    valor = document.getElementById('cep').value;
    var cep = valor.replace(/\D/g, '');
    if (cep != "") {
        var validacep = /^[0-9]{8}$/;
        if (validacep.test(cep)) {
            document.getElementById('rua').value = "...";
            document.getElementById('bairro').value = "...";
            document.getElementById('cidade').value = "...";
            document.getElementById('uf').value = "...";
            var script = document.createElement('script');
            script.src = 'https://viacep.com.br/ws/' + cep + '/json/?callback=meu_callback';
            document.body.appendChild(script);
        } else {
            limpa_formulário_cep();
            alert("Formato de CEP inválido.");
        }
    } else {
        limpa_formulário_cep();
    }
};
//scripts do viacep 