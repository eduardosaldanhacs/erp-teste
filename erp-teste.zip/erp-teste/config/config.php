<?php

session_start();
include("functions.php");
// error_reporting(0); // Desativa a exibição de erros
// ini_set('display_errors', '0'); // Garante que erros não sejam exibidos
// ini_set('log_errors', '1'); // Mantém o log de erros ativo
// ini_set('error_log', '/caminho/para/o/log/php_errors.log'); // Define o arquivo de log

define("BASE_URL", "http://localhost/erp-teste/");
