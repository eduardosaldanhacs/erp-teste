<?php
require_once("config/config.php");
require_once("models/Database.php");

header('Content-Type: application/json');

/*exemplo
     {
       "pedido_id": 9,
       "status": "Cancelado"
     }
      

     { 
     "pedido_id": 8,
     "status": "Enviado"
    }
*/

//dados json
$input = json_decode(file_get_contents("php://input"), true);

//verifica dados necessários
if (!isset($input['pedido_id']) || !isset($input['status'])) {
    http_response_code(400);
    echo json_encode(['erro' => 'Dados inválidos']);
    exit;
}

$pedido_id = (int)$input['pedido_id'];
$status = trim($input['status']);

try {
   
    // CANCELAR PEDIDO
    if (strtolower($status) === 'cancelado') {
        $stmt = Database::getConnection()->prepare("DELETE FROM orders WHERE id = ?");
        $stmt->execute([$pedido_id]);

        echo json_encode(['mensagem' => "Pedido #$pedido_id cancelado e removido."]);
    } else {
        // ATUALIZAR STATUS DO PEDIDO
        $stmt = Database::getConnection()->prepare("UPDATE orders SET status = ? WHERE id = ?");
        $stmt->execute([$status, $pedido_id]);

        echo json_encode(['mensagem' => "Status do pedido #$pedido_id atualizado para '$status'."]);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['erro' => 'Erro ao processar: ' . $e->getMessage()]);
}
