<?php
require_once 'Database.php';
class Order
{
    public $id;
    public $client_name;
    public $client_email;
    public $address;
    public $status;
    public $total;

    public function __construct($client_name, $client_email, $address, $status, $total)
    {
        $this->client_name = $client_name;
        $this->client_email = $client_email;
        $this->address = $address;
        $this->status = $status;
        $this->total = $total;
    }

    public function save()
    {

        $stmt = Database::getConnection()->prepare("
            INSERT INTO orders (client_name, client_email, address, status, total)
            VALUES (:name, :email, :address, 'Pendente', :total)
        ");

        $stmt->execute([
            ':name' => $this->client_name,
            ':email' => $this->client_email,
            ':address' => $this->address,
            ':total' => $this->total
        ]);

        $this->id = Database::getConnection()->lastInsertId();
        return $this->id;
    }

    public static function listAll()
    {
        $stmt = Database::getConnection()->query("SELECT * FROM orders WHERE deleted_at IS NULL ORDER BY id DESC");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function listProducts($order_id)
    {
        $stmt = Database::getConnection()->prepare("SELECT * FROM order_items WHERE order_id = :order_id AND deleted_at IS NULL");
        $stmt->execute([':order_id' => $order_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    public static function deleteOrder($id)
    {
        try {
            Database::getConnection()->beginTransaction();

            $stmt1 = Database::getConnection()->prepare("UPDATE order_items SET deleted_at = NOW() WHERE order_id = :order_id");
            $stmt1->execute([':order_id' => $id]);

            $stmt2 = Database::getConnection()->prepare("UPDATE orders SET deleted_at = NOW() WHERE id = :id");
            $stmt2->execute([':id' => $id]);

            Database::getConnection()->commit();
            return true;
        } catch (PDOException $e) {
            Database::getConnection()->rollBack();
            return false;
        }
    }



    public function saveItems($cart)
    {

        $stmt = Database::getConnection()->prepare("
            INSERT INTO order_items (order_id, product_name, quantity, price)
            VALUES (:order_id, :product_name, :quantity, :price)
        ");

        foreach ($cart as $item) {
            $stmt->execute([
                ':order_id' => $this->id,
                ':product_name' => $item['name'],
                ':quantity' => $item['amount'],
                ':price' => $item['price']
            ]);
        }
    }
}
