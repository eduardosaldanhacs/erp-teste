<?php
require("config/config.php");
require("models/Database.php");
require("models/Order.php");
require("vendor/autoload.php"); // carrega PHPMailer via Composer

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);

$completeAddress = $_POST['rua'] . ", " . $_POST['bairro'] . " - " . $_POST['cidade'] . "/" . $_POST['uf'] . " - CEP: " . $_POST['cep'];

$name = trim($_POST['client_name']);
$email = trim($_POST['client_email']);
$address = $completeAddress; 

//validar email
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die("E-mail inválido.");
}



$pedido_id = Database::getConnection()->lastInsertId();



$mail = new PHPMailer(true);
//biblioteca para ocultar dados sensíveis
$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
$dotenv->load();
try {
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username = $_ENV['SMTP_USERNAME'];
    $mail->Password = $_ENV['SMTP_PASSWORD'];
    $mail->SMTPSecure = 'tls';
    $mail->Port       = 587;
    $mail->CharSet    = 'UTF-8';
    $mail->setFrom('saldanhatestemail@gmail.com', 'Eduardo');
    $mail->addAddress($email, $name);

    $mail->isHTML(true);
    $mail->Subject = "Confirmação do Pedido #$pedido_id";

    //criar html dos produtos do carrinho
    $produtosHTML = '';
    foreach ($_SESSION['cart'] as $item) {
        $nomeProduto = $item['name'];
        $quantidade = $item['amount'];
        $preco = number_format($item['price'], 2, ',', '.');
        $subtotal = number_format($item['price'] * $item['amount'], 2, ',', '.');
        $produtosHTML .= "
        <li>
            <strong>$nomeProduto</strong><br>
            Quantidade: $quantidade<br>
            Preço unitário: R$ $preco<br>
            Subtotal: R$ $subtotal
        </li><br>";
    }

    $totalGeral = number_format($_SESSION['total_cart'], 2, ',', '.');


    //montar coropo do email
    $mail->Body = "
    <h2>Olá, {$name}!</h2>
    <p>Recebemos seu pedido com sucesso.</p>

    <h4>📦 Produtos:</h4>
    <ul>$produtosHTML</ul>

    <p><strong>💰 Total:</strong> R$ $totalGeral</p>

    <h4>📍 Endereço de Entrega:</h4>
    <p>$completeAddress</p>

    <p>Obrigado por comprar conosco!</p>
";


    $mail->send();


    //armazenar pedido no banco
    $order = new Order($name, $email, $address, 'Pendente', $_SESSION['total_cart']);
    $order->save();

    //salvar itens do pedido
    if (isset($_SESSION['cart']) && count($_SESSION['cart']) > 0) {
        $order->saveItems($_SESSION['cart']);
    }

    message('Pedido registrado e e-mail enviado com sucesso!', 'success');
    header("Location: " . BASE_URL . "order_list");
} catch (Exception $e) {
    message('Pedido registrado, mas erro ao enviar e-mail: ' . $e->getMessage(), 'error');
}
