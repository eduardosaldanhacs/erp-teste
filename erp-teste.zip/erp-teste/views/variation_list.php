<?php
$query = "SELECT * FROM variation WHERE active = 1";
$stmt = Database::getConnection()->prepare($query);
$stmt->execute();
$variations = $stmt->fetchAll();
?>

<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="col-3 text-end">
                <a href="<?= BASE_URL ?>new_variation" class="text-light text-decoration-none btn btn-success mb-3 w-100">Nova Variação</button"></a>
            </div>
            <table class="table table-striped">
                <thead>
                    <tr class="text-center">
                        <th scope="col">#</th>
                        <th scope="col">Variação</th>
                        <th scope="col">Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1;
                    foreach ($variations as $variation): ?>
                        <tr class="align-middle text-center">
                            <td scope="row" class="col-2"><?= $i ?></th>
                            <td class="col-3"><?= $variation['name'] ?></td>
                            <td class="col-4">
                                <form action="<?= BASE_URL ?>new_variation" method="POST" style="display:inline;">
                                    <input type="hidden" name="id" value="<?= $variation['id'] ?>">
                                    <button type="submit" class="btn btn-info">Editar</button>
                                </form>
                                <form action="<?= BASE_URL ?>controllers/delete_variation.php" method="POST" style="display:inline;">
                                    <input type="hidden" name="id" value="<?= $variation['id'] ?>">
                                    <button type="submit" class="btn btn-danger">Excluir</button>
                                </form>

                            </td>
                        </tr>
                    <?php
                        $i++;
                    endforeach; ?>
                    <?php if (empty($variations)) { ?>
                        <tr>
                            <td colspan='8' class='text-center'>Nenhum pedido encontrado</td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>