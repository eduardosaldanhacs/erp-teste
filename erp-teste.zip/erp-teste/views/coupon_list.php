<?php
include_once("models/Coupon.php");
$coupons = Coupon::listAll();
?>
<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="col-3 text-end">
                <a href="<?= BASE_URL ?>new_coupon" class="text-light text-decoration-none btn btn-success mb-3 w-100">Novo Cupom</a>
            </div>
            <table class="table table-striped">
                <thead>
                    <tr class="text-center">
                        <th>#</th>
                        <th>Código</th>
                        <th>Desconto</th>
                        <th>Validade</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1; ?>
                    <?php foreach ($coupons as $coupon): ?>
                        <tr class="align-middle text-center">
                            <td><?= $i ?></td>
                            <td><?= $coupon['code'] ?></td>
                            <td><?= $coupon['discount'] ?></td>
                            <td><?= formataData($coupon['validate']) ?></td>
                            <td>
                                <div class="d-flex justify-content-center">
                                    <form action="<?= BASE_URL ?>new_coupon" class="ms-1" method="POST">
                                        <input type="hidden" name="id" value="<?= $coupon['id'] ?>">
                                        <button type="submit" class="btn btn-info">Editar</button>
                                    </form>
                                    <form action="<?= BASE_URL ?>controllers/coupon_controller.php" class="ms-1" method="POST">
                                        <input type="hidden" name="id" value="<?= $coupon['id'] ?>">
                                        <input type="hidden" name="action" value="delete">
                                        <button type="submit" class="btn btn-danger">Excluir</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php $i++;
                    endforeach; ?>
                    <?php if (empty($coupons)) { ?>
                        <tr>
                            <td colspan='8' class='text-center'>Nenhum cupom encontrado</td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>

            <div id="mensagem" class="mt-3"></div>
            <div></div>
        </div>
    </div>
</div>

<!-- jQuery ou JavaScript puro para AJAX -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(".comprar-btn").click(function() {
        const id = $(this).data("id");
        const nome = $(this).data("nome");
        const preco = $(this).data("preco");

        $.post("<?= BASE_URL ?>controllers/add_to_cart.php", {
            id: id,
            nome: nome,
            preco: preco
        }, function(resposta) {
            $("#mensagem").html('<div class="alert alert-success">' + resposta + '</div>');
        });
    });
</script>