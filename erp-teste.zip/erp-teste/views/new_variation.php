<?php
if(isset($_POST['id']) && !empty($_POST['id'])) {
  $id = $_POST['id'];
  $query = "SELECT * FROM variation WHERE id = $id";
  $stmt = $conn->prepare($query);
  $stmt->execute();
  $variation = $stmt->fetch();
  $button = "Atualizar";
} else {
  $button = "Cadastrar";
}


?>

<div class="container">
  <div class="col-6">
    <form method="POST" action="<?= BASE_URL ?>controllers/create_variation.php" class="p-4 bg-light rounded">
      <h2 class="text-center">Nova Variação</h2>
      <div class="col-12">
        <label for="Variação" class="form-label">Variação: </label>
        <input class="form-control text-center mb-2" name="name" value="<?= $variation['name'] ?? '' ?>">
      </div>
      <!-- <div class="col-12">
        <label for="Tamanho" class="form-label">Tamanho: </label>
        <input class="form-control text-center mb-2" name="tamanho" value="<?= $variation['tamanho'] ?? '' ?>">
      </div> -->
      <div class="mt-3">
        <button class="btn btn-outline-success w-100" type="submit"><?= $button ?></button>
      </div>
    </form>
  </div>
</div>