<?php
include_once("models/Order.php");
$orders = Order::listAll();
?>

<div class="container">
    <div class="row">
        <div class="col-12">
            <table class="table table-striped">
                <thead>
                    <tr class="text-center">
                        <th>#</th>
                        <th>Dados do Cliente</th>
                        <th>Endereço</th>
                        <th>Pedidos</th>
                        <th>Total</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1; ?>
                    <?php foreach ($orders as $order): ?>
                        <tr class="align-middle text-center">
                            <td><?= $i ?></td>
                            <td><?= $order['client_name'] ?><br>
                            <?= $order['client_email'] ?></td>
                            <td title="<?= $order['address'] ?>"><?= textLimit($order['address'], 12) ?></td>
                            <td><?php $products = Order::listProducts($order['id']) ?>
                                <ul class="list-unstyled">
                                    <?php foreach ($products as $product): ?>
                                        <li><?= $product['product_name'] ?> (<?= $product['quantity'] ?>)</li>

                                    <?php endforeach; ?>
                                </ul>
                            </td>
                            <td>R$ <?= number_format($order['total'], 2, ',', '.') ?></td>
                            <td><?= $order['status'] ?></td>
                            <td>
                                <div class="d-flex justify-content-center align-items-center">
                                    <form action="<?= BASE_URL ?>controllers/order_controller.php" class="ms-1" method="POST">
                                        <input type="hidden" name="id" value="<?= $order['id'] ?>">
                                        <input type="hidden" name="action" value="delete">
                                        <button type="submit" class="btn btn-danger">Excluir</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php $i++;
                    endforeach;  ?>
                    <?php if(empty($orders)) { ?>
                        <tr><td colspan='8' class='text-center'>Nenhum pedido encontrado</td></tr> 
                    <?php } ?>
                </tbody>
            </table>

            <div id="mensagem" class="mt-3"></div>
            <div></div>
        </div>
    </div>
</div>

<!-- jQuery ou JavaScript puro para AJAX -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(".comprar-btn").click(function() {
        const id = $(this).data("id");
        const name = $(this).data("name");
        const price = $(this).data("price");

        $.post("<?= BASE_URL ?>controllers/add_to_cart.php", {
            id: id,
            name: name,
            price: price
        }, function(resposta) {
            $("#mensagem").html('<div class="alert alert-success">' + resposta + '</div>');
        });
    });
</script>