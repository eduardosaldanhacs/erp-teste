<?php
include_once('models/Coupon.php');

if (isset($_POST['id']) && !empty($_POST['id'])) {
    $coupon = Coupon::searchCouponById($_POST['id']);
    $action = "update";
    $button = "Atualizar";
} else {
    $action = "create";
    $button = "Cadastrar";
}
?>

<div class="container">
    <div class="col-6">
        <form method="POST" class="p-4 bg-light rounded" action="<?= BASE_URL ?>controllers/coupon_controller.php">
            <h2 class="text-center">Novo Cupom</h2>
            <div class="col-12">
                <label for="Codigo" class="form-label">Código: </label>
                <input class="form-control mb-2" name="code" value="<?= $coupon['code'] ?? '' ?>">
            </div>
            <div class="col-12">
                <label for="Desconto" class="form-label">Desconto: </label>
                <input class="form-control mb-2" name="discount" value="<?= $coupon['discount'] ?? '' ?>">
            </div>
            <div class="col-12">
                <label for="Validade" class="form-label">Validade: </label>
                <input type="date" class="form-control mb-2" name="validate" value="<?= $coupon['validate'] ?? '' ?>">
            </div>
            <div class="mt-3">
                <input type="hidden" name="action" value="<?= $action ?>">
                <input type="hidden" name="id" value="<?= $coupon['id'] ?? '' ?>">
                <button class="btn btn-outline-success w-100" type="submit"><?= $button ?></button>
            </div>
        </form>
    </div>
</div>