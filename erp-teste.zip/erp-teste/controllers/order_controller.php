<?php
include_once("../config/config.php");
include_once("../models/Order.php");

$action = $_POST['action'];
$id = $_POST['id'] ?? null;

//deletar pedido
if ($action == "delete") {
    if (Order::deleteOrder($id)) {
        message('Pedido excluído com sucesso!', 'success');
        header("Location:" . BASE_URL . "order_list");
        exit;
    } else {
        message('Erro ao excluir o pedido!', 'error');
        header("Location:" . BASE_URL . "order_list");
        exit;
    }
} else {
    message('Ação inválida!', 'error');
    header("Location:" . BASE_URL . "order_list");
    exit;
}
