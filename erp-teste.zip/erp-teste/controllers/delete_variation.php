<?php
include("../config/config.php");
if (isset($_POST['id']) && !empty($_POST['id'])) {
    $id = $_POST['id'];
    $query = "UPDATE variation SET active = 0 WHERE id = " . $id;
    $stmt = $conn->prepare($query);
    $stmt->execute();
    header("Location:" . BASE_URL . "variation_list");
}
