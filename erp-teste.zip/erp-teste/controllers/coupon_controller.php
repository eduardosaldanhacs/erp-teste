<?php

include_once("../config/config.php");
include_once("../models/Coupon.php");

$action = $_POST['action'];
//criar cupom
if ($action == 'create') {
    $coupon = new Coupon($_POST['code'], $_POST['discount'], $_POST['validate']);
    if ($coupon->salvar($coupon)) {
        message('Cupom cadastrado com sucesso!', 'success');
        header("Location:"  . BASE_URL . "coupon_list");
    } else {
        message('Erro ao cadastrar cupom!', 'error');
        header("Location:"  . BASE_URL . "coupon_list");
    }
//atualizar cupom
} else if ($action == "update") {
    $coupon = new Coupon($_POST['code'], $_POST['discount'], $_POST['validate'], $_POST['id']);
    if ($coupon->updateCoupon($coupon)) {
        message('Cupom atualizado com sucesso!', 'success');
        header("Location:"  . BASE_URL . "coupon_list");
    } else {
        message('Erro ao atualizar cupom!', 'error');
        header("Location:"  . BASE_URL . "coupon_list");
    }
//deletar cupom
} else if ($action == "delete") {
    $id = $_POST['id'];
    if (Coupon::deleteCoupon($id)) {
        message('Cupom excluído com sucesso!', 'success');
        header("Location:"  . BASE_URL . "coupon_list");
    } else {
        message('Erro ao excluir cupom!', 'error');
        header("Location:"  . BASE_URL . "coupon_list");
    }
} else {
// ação inválida
    message('Ação inválida!', 'error');
    header("Location:"  . BASE_URL . "coupon_list");
}
