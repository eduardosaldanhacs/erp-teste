<?php
require_once('../models/Database.php');
session_start();

// Simulação de subtotal vindo da sessão do carrinho
$subtotal = $_SESSION['total_cart'] ?? 0;

$codigo = $_POST['codigo'] ?? '';
$codigo = trim($codigo);

$response = ['valido' => false, 'mensagem' => 'Cupom inválido.'];

if ($codigo === '') {
    echo json_encode($response);
    exit;
}

$stmt = Database::getConnection()->prepare("SELECT * FROM coupons WHERE code = ? AND validate >= CURDATE()");
$stmt->execute([$codigo]);
$cupom = $stmt->fetch(PDO::FETCH_ASSOC);
if ($cupom) {
    if ($subtotal >= $cupom['discount']) {
        $desconto = $cupom['discount'];
        $subtotalComDesconto = max(0, $subtotal - $desconto);

        // Calcular frete
        if ($subtotalComDesconto > 200) {
            $frete = 0;
        } elseif ($subtotalComDesconto >= 52 && $subtotalComDesconto <= 166.59) {
            $frete = 15;
        } else {
            $frete = 20;
        }

        $total = $subtotalComDesconto + $frete;
        $_SESSION['total_cart'] = $total;
        echo json_encode([
            'valido' => true,
            'desconto' => (float) $desconto,
            'subtotal' => (float) $subtotal,
            'frete' => (float) $frete,
            'total' => (float) $total
        ]);
    } else {
        $response['mensagem'] = 'Subtotal insuficiente para usar esse cupom.';
        echo json_encode($response);
    }
} else {
    echo json_encode($response);
}
