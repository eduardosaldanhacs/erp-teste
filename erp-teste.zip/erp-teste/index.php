<?php
include_once("config/config.php");
include_once("config/functions.php");
include_once("models/Database.php");
$exibirCarrinho = isset($_SESSION['exibir_carrinho']) && $_SESSION['exibir_carrinho'] == true;
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="assets/bootstrap.min.css">
    <title>Mini ERP - Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 40px;
            background-color: #f5f5f5;
        }

        h1 {
            color: #333;
        }
    </style>
</head>

<body class="bg-secondary">
    <div class="container-fluid py-3">
        <!-- Header -->
        <div class="text-center mb-4">
            <h1 class="text-light">Mini ERP - Painel de Controle</h1>
            <p class="text-primary">By: <a href="https://eduardosaldanha.online" target="_blank" class="text-light">Eduardo Saldanha</a> </p>
            <a href="#"><i class="bi bi-cart text-light fs-4"></i></a>
            <div class="col-auto text-end">
                <div class="btn-group col-1" onclick="exibirCarrinho()">
                    <button class="btn btn-success"> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-cart" viewBox="0 0 16 16">
                            <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .491.592l-1.5 8A.5.5 0 0 1 13 12H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5M3.102 4l1.313 7h8.17l1.313-7zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4m7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4m-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2m7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2" />
                        </svg>
                    </button>
                </div>
            </div>
        </div>
        <!-- Carrinho e Botão -->
        <? include_once('views/cart_view.php'); ?>
        <!-- Painel principal -->
        <div class="row mt-4">
            <!-- Menu Lateral -->
            <div class="col-3">
                <div class="p-3 rounded shadow" style="background-color: #2a2a2a;">
                    <a href="<?= BASE_URL ?>new_product" class="btn btn-info mb-2 w-100">Produto</a>
                    <a href="<?= BASE_URL ?>product_list" class="btn btn-info mb-2 w-100">Estoque</a>
                    <a href="<?= BASE_URL ?>order_list" class="btn btn-info mb-2 w-100">Pedidos</a>
                    <a href="<?= BASE_URL ?>variation_list" class="btn btn-info mb-2 w-100">Variações</a>
                    <a href="<?= BASE_URL ?>coupon_list" class="btn btn-info mb-2 w-100">Cupons</a>
                </div>
            </div>

            <!-- Conteúdo dinâmico -->
            <div class="col-9 min-vh-50">
                <?php
                $pag = $_GET['a'] ?? '';
                switch ($pag) {
                    case 'new_product':
                        include('views/new_product.php');
                        break;
                    case 'new_variation':
                        include('views/new_variation.php');
                        break;
                    case 'variation_list':
                        include('views/variation_list.php');
                        break;
                    case 'product_list':
                        include('views/product_list.php');
                        break;
                    case 'listar_pedidos':
                        include('views/listar_pedidos.php');
                        break;
                    case 'new_coupon':
                        include('views/new_coupon.php');
                        break;
                    case 'coupon_list':
                        include('views/coupon_list.php');
                        break;
                    case 'order_list':
                        include('views/order_list.php');
                        break;
                    default:
                        include('views/product_list.php');
                }
                ?>
            </div>
        </div>
        <?php if (isset($_SESSION['message'])) { ?>
            <div id="alert-msg" style="position: fixed; bottom: 0; left: 50%; transform: translateX(-50%); width: 500px; z-index: 10;">
                <div class="col-12 text-center">
                    <div class="alert <?= $_SESSION['type'] == 'success' ? 'alert-success' : 'alert-danger' ?> mt-3" role="alert">
                        <?= $_SESSION['message'] ?>
                        <?php unset($_SESSION['message'], $_SESSION['type']); ?>
                    </div>
                </div>
            </div>

            <script>
                //remover mensagem após 3 segundos
                setTimeout(function() {
                    var alert = document.getElementById('alert-msg');
                    if (alert) {
                        alert.style.transition = 'opacity 0.5s ease';
                        alert.style.opacity = '0';
                        setTimeout(() => alert.remove(), 800);
                    }
                }, 3000);
            </script>
        <?php } ?>

    </div>
</body>

</html>

<script>
    function fecharCarrinho() {
        const carrinho = document.getElementById("carrinho");
        carrinho.style.display = "none";

        fetch('controllers/show_cart_ajax.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: 'exibir=0'
        });
    }



    function exibirCarrinho() {
        const carrinho = document.getElementById("carrinho");
        let isVisible;

        if (carrinho.style.display == "none") {
            console.log("entrou");
            carrinho.style.display = "block";
            isVisible = true;
        } else {
            console.log("saiu");
            carrinho.style.display = "none";
            isVisible = false;
        }

        //ajax para salvar a opção de exibir ou não o carrinho
        fetch('controllers/show_cart_ajax.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: 'exibir=' + (isVisible ? '1' : '0')
        });
    }
</script>




<!-- jquery para aplicar cupom e calcular novo valor -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $('#cupom').on('keypress', function(e) {
        if (e.which === 13) {
            e.preventDefault();

            const codigo = $(this).val().trim();
            if (codigo === '') return;

            $.ajax({
                url: '<?= BASE_URL ?>controllers/check_coupon.php',
                type: 'POST',
                data: {
                    codigo
                },
                dataType: 'json',
                success: function(res) {
                    if (res.valido) {
                        $('#mensagem-cupom')
                            .text(`Cupom aplicado: R$ ${res.desconto.toFixed(2).replace('.', ',')}`)
                            .css('color', 'green');

                        $('#subtotal').text('R$ ' + res.subtotal.toFixed(2).replace('.', ','));
                        $('#frete').text('R$ ' + res.frete.toFixed(2).replace('.', ','));
                        $('#total').text('R$ ' + res.total.toFixed(2).replace('.', ','));
                    } else {
                        $('#mensagem-cupom')
                            .text(res.mensagem)
                            .css('color', 'red');
                    }
                },
                error: function() {
                    $('#mensagem-cupom')
                        .text('Erro ao validar o cupom.')
                        .css('color', 'red');
                }
            });
        }
    });
</script>