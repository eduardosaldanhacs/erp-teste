<?php
function formataData($data) {
    $data = new DateTime($data);
    return $data->format("d/m/Y");
}

function message($message, $type) {
    $_SESSION['message'] = $message;
    $_SESSION['type'] = $type;
}

function textLimit($text, $limit) {
    if (strlen($text) <= $limit) {
        return $text;
    }
    return substr($text, 0, $limit) . '...';
}

?>