<?php
session_start();
//ajax para exibir ou não o carrinho e salvar a opção na sessão
if (isset($_POST['exibir'])) {
    $_SESSION['exibir_carrinho'] = $_POST['exibir'] == '1' ? true : false;
}
echo json_encode(['exibir' => $_SESSION['exibir_carrinho']]);