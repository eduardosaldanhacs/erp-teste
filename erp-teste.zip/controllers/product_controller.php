<?php
include_once("../config/config.php");
include_once("../models/Product.php");

$action = $_POST['action'];
$id = $_POST['id'] ?? null;
//criar produto
if ($action == "create") {
    $p = new Product($id, $_POST['name'], $_POST['price'], $_POST['stock'], ($_POST['variations']));
    if($p->save($p)) {
        message('Produto cadastrado com sucesso!', 'success');
        header("Location:"  . BASE_URL . "product_list");
    } else {
        message('Erro ao cadastrar produto!', 'error');
        header("Location:"  . BASE_URL . "product_list");
    }
//atualizar produto
} else if ($action == "update") {
    $p = new Product($id, $_POST['name'], $_POST['price'], $_POST['stock'], ($_POST['variations']));
    if ($p->updateProduct($p)) {
        message('Produto atualizado com sucesso!', 'success');
        header("Location:"  . BASE_URL . "product_list");
    } else {
        message('Erro ao atualizar produto!', 'error');
        header("Location:"  . BASE_URL . "product_list");
    }
//deletar produto
} else if ($action == "delete") {
    if (Product::deleteProduct($id)) {
        message('Produto excluído com sucesso!', 'success');
        header("Location:"  . BASE_URL . "product_list");
    } else {
        message('Erro ao excluir produto!', 'error');
        header("Location:"  . BASE_URL . "product_list");
    }
//ação inválida	
} else {
    message('Ação inválida!', 'error');
    header("Location:"  . BASE_URL . "product_list");
}
