<?php
include_once("../config/config.php");

//adicionar produto ao carrinho
$id = $_POST['id'];
$name = $_POST['name'];
$price = $_POST['price'];

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

if (!isset($_SESSION['cart'][$id])) {
    $_SESSION['cart'][$id] = [
        'name' => $name,
        'price' => $price,
        'amount' => 1
    ];
} else {
    $_SESSION['cart'][$id]['amount']++;
}
header("Location:" . BASE_URL . "product_list");
message("Produto '$name' adicionado ao carrinho com sucesso!", 'success');
