<?php
include("../config/config.php");
include("../models/Variation.php");
$variation = new Variation();

$variation->name = $_POST['name'];
$variation->active = 1;

if($variation->registerVariation($variation->name, $variation->active)) {
    message('Variation criada com sucesso!', 'success');
    header("Location:" . BASE_URL . "variation_list");
    exit;
} else {
    message('Erro ao criar a variação!', 'error');
    header("Location:" . BASE_URL . "new_variation");
    exit;
}
?>