<?php
    include_once("../config/config.php");
    //remover produto do carrinho
    $id = $_GET['id'];
    unset($_SESSION['cart'][$id]);
    message('Item removido com sucesso!', 'success');
    header('Location:' . BASE_URL . 'product_list');
?>